show user;

grant all on dealer to ming, zongyao, fangyu;
grant all on customer to ming, zongyao, fangyu;
grant all on reviews to ming, zongyao, fangyu;
grant all on connections to ming, zongyao, fangyu;
grant all on favorites to ming, zongyao, fangyu;
grant all on manufacturer to ming, zongyao, fangyu;
grant all on car_model to ming, zongyao, fangyu;
grant all on features to ming, zongyao, fangyu;
grant all on inventory to ming, zongyao, fangyu;

